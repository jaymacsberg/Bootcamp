


package videorentalsystem;
import videorentalsystem.Gui.ReceiptGui;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author JAYMACSBERG
 */
public class Receipt extends ReceiptGui {
    /*------------------------------
    The Constructor of the class
    -----------------------------------*/
    public Receipt(){
        printTotalCost();
 PrintBtn.addActionListener(new receiptHandler());   
 ExitBtn.addActionListener(new receiptHandler());   
}
    /*----------------------------------------------
    Abstract class to implement ActionListener
    --------------------------------------------*/
           public class receiptHandler implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e){
    if(e.getSource()==PrintBtn){
     JOptionPane.showMessageDialog(null,"Receipt Printed Successfully");   
     receiptNumberField.setText("");
     receiptAmnField.setText("");
    }
    if(e.getSource()==ExitBtn){
        dispose();
    }
    }
}    
      String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
     /*----------------------------------------------------
     pre Condition: Total Cost Field must not be empty  
     and must not be less than or equal to zero
    --------------------------------------------------------*/                     
    protected void printTotalCost(){
    try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String value= JOptionPane.showInputDialog("Input Customer Unique Id");
      String Query = "SELECT * FROM COST WHERE CUSTOMER_ID='"+value+"'";
            
     ResultSet rs=  stmt.executeQuery(Query); 
       while(rs.next()){
       receiptAmnField.setText(rs.getString(2));
            }
    }
     catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.toString());
        }   
   }
    /*--------------------------------------------------------
  post Condition:  All item bought must have a total cost
   ----------------------------------------------------------- */
}
