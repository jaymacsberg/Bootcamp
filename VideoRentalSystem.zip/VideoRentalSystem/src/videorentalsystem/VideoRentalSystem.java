
package videorentalsystem;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import videorentalsystem.Gui.MainGuiInterface;
/**
 *
 * @author JAYMACSBERG
 */
public class VideoRentalSystem {
    
/*--------------------------------------------
    The main Class that Contains the Main Method.
   ------------------------------------------ */
    public static void main(String[] args) {
try {
    UIManager.put("nimbusBase", new Color(148,129,38));
UIManager.put("nimbusBlueGrey", new Color(190,125,87));
UIManager.put("control", new Color(190,125,87));

    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
   JOptionPane.showMessageDialog(null,e.toString());
}
        new MainGuiInterface();
    }
    
}
