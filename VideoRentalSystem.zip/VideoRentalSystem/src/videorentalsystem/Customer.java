
package videorentalsystem;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
import videorentalsystem.Gui.CustomerGui;
/**
 *
 * @author JAYMACSBERG
 */
public class Customer extends CustomerGui  { 
   int idNo=1;
   /*-----------------------------------
  the default Constructor without parameter
  --------------------------------------- */
 public Customer(){
     GenId();
  Handler handler= new Handler();   
  submitBtn.addActionListener(handler);
  exitBtn.addActionListener(handler);
 }
 /*-------------------------------------------
 abstract class that implements actionListener
 -------------------------------------------*/
 public class Handler implements ActionListener{
  @Override
  public void actionPerformed(ActionEvent ae){   
      
      if(ae.getSource()==submitBtn){
      storeCustomerData();    
      }
      if(ae.getSource()==exitBtn){
      dispose();    
      }
  }
 }   
                    String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
  /*--------------------------------------------------------
  pre condition: A customer must hava a membership Number                     
     ------------------------------------------------------ */
 public void GenId(){      
    String prevMemmId=null;
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="SELECT COUNT(MEMSHIPID) FROM CUSTOMER";
        ResultSet rst=stmt.executeQuery(Query);
        if(rst.next()){
            prevMemmId=rst.getString(1);
    }
        idNo=Integer.parseInt(prevMemmId);
        idNo +=20000000;
        memshipIdField.setText(""+idNo);
    }
        catch(Exception e){
                JOptionPane.showMessageDialog(null,e.toString());
                }
    }
 /*-------------------------------------------------------------------
pre condition: the textFields must all be filled out with information
 all textField Must not be empty.
 ---------------------------------------------------------------------*/
 public void storeCustomerData(){    
       try{
              Connection connnect= DriverManager.getConnection(url,userName,password);
              Statement state=connnect.createStatement();         
String Query= "INSERT INTO CUSTOMER(MEMSHIPID,NAME,ADDRESS,PHONE,MEMSTARTDATE) VALUES('" +memshipIdField.getText()+"','"+NameField.getText()+"',"
 + " '"+AddressField.getText()+"', '"+phoneField.getText()+"' ,'"+memStartDateField.getText()+"')";
             
state.execute(Query);
     JOptionPane.showMessageDialog(null,"Customer Registered Successfully");
     NameField.setText("");
     AddressField.setText("");
     phoneField.setText("");
     memshipIdField.setText("");
     GenId();
              }
              catch(SQLException ex){
                JOptionPane.showMessageDialog(null,ex.toString());
              }      
  }
 /*--------------------------------------------------------
Pre condition: A customer must have an overdueDate
 ---------------------------------------------------------*/
   public void checkOverDueDate(){
    try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String idInput=JOptionPane.showInputDialog("Input Video Id Code:");
      String query = "SELECT MOVIE_COD,MOVIE_TITLE,DUE_DATE_RETURN FROM RENTAL_DETAILS WHERE MOVIE_COD='"+idInput+"'";
               ResultSet rs = stmt.executeQuery(query);   
      while(rs.next()){
        movieCodDisplayLbl.setText(rs.getString(1)); 
        titleDisplayLbl.setText(rs.getString(2)); 
       overDueDateDisplayLbl.setText(rs.getString(3));
  }  
       JOptionPane.showMessageDialog(null,"Movie_Cod: "+movieCodDisplayLbl.getText()+"\nMovie Title: "+titleDisplayLbl.getText()+
               "\nDue Return Date: "+overDueDateDisplayLbl.getText());
    }
              catch(SQLException ex){
                JOptionPane.showMessageDialog(null,ex.toString());
              }  
    /*-------------------------------------------------------
                    data is retrieved from the database
    ---------------------------------------------------------*/
   } 
}
