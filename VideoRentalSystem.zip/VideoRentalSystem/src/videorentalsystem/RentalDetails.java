/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;
import videorentalsystem.Gui.RentalDetailsGui;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author JAYMACSBERG
 */
public class RentalDetails  extends RentalDetailsGui{
 
   /*--------------------------------------
    The Constructor
    ---------------------------------------*/ 
    public RentalDetails(){
  OkBtn.addActionListener(new rentHandler());
  exitBtn.addActionListener(new rentHandler());
  selectRentalDetails();
  empIdGenerator();
    
    }
   String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
    private void selectRentalDetails(){
        try {
                Connection conn = DriverManager.getConnection(url, userName, password);
                Statement stmt = conn.createStatement();
                String value=JOptionPane.showInputDialog("Insert Video Code:");
                String query = "SELECT VIDEO_ID,TITLE,VIDEO_COST FROM RENTEDVIDEOS WHERE VIDEO_ID='"+value+"'";
                ResultSet rs = stmt.executeQuery(query);  
                while(rs.next()){
       movieCodField.setText(rs.getString(1));
        movieTitleField.setText(rs.getString(2));
        rentalPriceField.setText(rs.getString(3));
}               
        }
        catch(Exception ae){
            JOptionPane.showMessageDialog(null,ae.toString());
        }
    }
        String prevMemId=null;
        int empId=0;
        /*-------------------------------------------------------
        pre condition:All Employee must have A unique ID
        and the query statement must be semantically correct
        --------------------------------------------------------*/
        public void empIdGenerator(){
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="SELECT COUNT(EMPLOYEE_ID)FROM RENTAL_DETAILS";
        ResultSet rst=stmt.executeQuery(Query);
    
        if(rst.next()){
            prevMemId=rst.getString(1);
    }
        empId=Integer.parseInt(prevMemId);
        empId =empId+100000000;
        employeeIdField.setText(""+empId);
    }
        catch(Exception e){
                JOptionPane.showMessageDialog(null,e.toString());
                }
    }
        /*------------------------------
       post Coondition:  Employee Id is Generated
        -------------------------------*/
   
}
