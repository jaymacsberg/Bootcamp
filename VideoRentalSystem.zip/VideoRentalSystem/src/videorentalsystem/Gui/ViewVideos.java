/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem.Gui;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
import java.util.Date;
import java.text.DateFormat;
/**
 *
 * @author JAYMACSBERG
 */
public class ViewVideos extends JFrame{
Date rentedDate;
DateFormat format;
    protected JScrollPane tablePane;
    protected static JTable table;
    protected JButton rentBtn,exitBtn,SelectBtn;
    protected JPanel container, btnPanel,costPanel;
    protected JLabel displayCost,RentedDateLbl,nameField,idField;
    
    
    public ViewVideos(){
        setSize(800,250);
        setTitle("Videos Available");
        ComponentInit();
        validateMemNo();
        updateJTable();
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);
        rentBtn.addActionListener(new Handler());
        SelectBtn.addActionListener(new Handler());
        exitBtn.addActionListener(new Handler());
    }
    
    protected void ComponentInit(){
        nameField= new JLabel();
        idField= new JLabel();
        rentedDate= new Date();
        format=DateFormat.getDateInstance(DateFormat.MEDIUM);
        RentedDateLbl= new JLabel(""+format.format(rentedDate));
       
        displayCost=new JLabel("");
        rentBtn = new JButton("Rent");
        exitBtn = new JButton("Exit");
        SelectBtn = new JButton("Select");
        container = new JPanel();
        costPanel = new JPanel(new FlowLayout());
        btnPanel = new JPanel(new FlowLayout());
        String[] colNames = {"SN","Video Id Number",
                                "Title", "Producer", 
                                "Cost", "Rented Date"};
        
        Object[][] rowData = {
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null}};
        table = new JTable();
        table.setModel(new DefaultTableModel(rowData, colNames));
        
        table.setPreferredScrollableViewportSize(new Dimension(500, 70));
        table.setFillsViewportHeight(true);
        tablePane = new JScrollPane(table);
        
        container.add(tablePane);
        btnPanel.add(SelectBtn);
        btnPanel.add(rentBtn);
        btnPanel.add(exitBtn);
       // btnPanel.add(nameField);
       // btnPanel.add(idField);
        costPanel.add(displayCost);
        add(tablePane);
        add(btnPanel, BorderLayout.SOUTH);
        add(costPanel, BorderLayout.PAGE_START);
    }
    
   public static void main(String[] args) {
        new ViewVideos();
    }
    
     String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
                          
    private void updateJTable(){
        try {
                Connection conn = DriverManager.getConnection(url, userName, password);
                Statement stmt = conn.createStatement();
                String query = "SELECT * FROM VIDEOS";
                ResultSet rs = stmt.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
                
            }
        catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }
}
    double mainCost=0;
    double totalCost=0;
    public class Handler implements ActionListener{
        public void actionPerformed(ActionEvent ae){
       if(ae.getSource()==rentBtn){
           printTotalPrice();
     JOptionPane.showMessageDialog(null,"Rentage Successful!!\n Total Price is =N"+Sum);
       }
       if(ae.getSource()==SelectBtn){   
        RowDataSelection(); 
        totalCostSummation(); 
        RentedVideos();  
       }
       if(ae.getSource()==exitBtn){
           dispose();
        }
        }
    }
    protected double RowDataSelection(){
      int index= table.getSelectedRow();
      TableModel model=table.getModel();
      String Cost= model.getValueAt(index,3).toString();
        mainCost=Double.parseDouble(Cost);
      return mainCost;
    }
    String Sum;
   protected void totalCostSummation(){
      totalCost+= mainCost;
      Sum= String.format("%,.3f",totalCost);
      
   } 
   protected void printTotalPrice(){
       displayCost.setText("Total Cost Of Video= N"+Sum);
      System.out.println(Sum);
      try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String query = "INSERT INTO COST(CUSTOMER_ID,TOTAL_COST)VALUES('"+idField.getText()+"','"+Sum+"')";
            
       stmt.execute(query);     
            }
     catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.toString());
        }   
   } 
      public void validateMemNo(){
      try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String idInput=JOptionPane.showInputDialog("Input Customer MemberShip Number");
      String query = "SELECT NAME, MEMSHIPID FROM CUSTOMER WHERE MEMSHIPID='"+idInput+"'";
               ResultSet rs = stmt.executeQuery(query);
      while(rs.next()){
       nameField.setText(rs.getString(1));
        idField.setText(rs.getString(2));         
  }   
            }
     catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.toString());
        } 
   }
   protected void RentedVideos(){
      int index= table.getSelectedRow();
      TableModel model=table.getModel();
      String ID= model.getValueAt(index,1).toString();
      String TITLE= model.getValueAt(index,2).toString();
      String COST= model.getValueAt(index,3).toString();
      String PRODUCER= model.getValueAt(index,4).toString();
     JOptionPane.showMessageDialog(null,"You have Selected The Movie Titled: "+TITLE);
      try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String query = "INSERT INTO RENTEDVIDEOS(CUSTOMER_NAME,MEMBERSHIPID,VIDEO_ID,TITLE,VIDEO_COST,PRODUCER,DATE_RENTED)"
              + " VALUES('"+nameField.getText()+"','"+idField.getText()+"','"+ID+"','"+TITLE+"',"
                 + "'"+COST+"','"+PRODUCER+"','"+RentedDateLbl.getText()+"')";
       stmt.execute(query);     
            }
     catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.toString());
        } 
   }
}