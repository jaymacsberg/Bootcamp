/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem.Gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
/**
 *
 * @author JAYMACSBERG
 */
public class RentalDetailsGui extends JFrame {
 protected JLabel movieCodLbl, MovieTitleLbl,movieCodField,movieTitleField,rentalPriceLbl,dueDate,employeeId,rentalPriceField,employeeIdField;
 protected JTextField dueDateField;
 protected JPanel mainPnl,btnPnl;
 protected Container container;
 
 protected JButton OkBtn,exitBtn;
 
 public RentalDetailsGui(){
     movieCodLbl= new JLabel("Movie Code:");
     dueDate= new JLabel("Due Date Of Return:");
     employeeId= new JLabel("Employee Identification Number:");
     MovieTitleLbl= new JLabel("Movie Title:");
     rentalPriceLbl= new JLabel("Rental Price:");
     
     movieCodField= new JLabel();
     movieTitleField= new JLabel();
     rentalPriceField= new JLabel();
     employeeIdField= new JLabel();
     dueDateField= new JTextField();
     OkBtn= new JButton("OK");
     exitBtn= new JButton("EXIT");
     
     mainPnl= new JPanel(new GridLayout(5,2));
     btnPnl= new JPanel(new FlowLayout());
     container=getContentPane();
     
     mainPnl.add(movieCodLbl);
     mainPnl.add(movieCodField);
     mainPnl.add(MovieTitleLbl);
     mainPnl.add(movieTitleField);
     mainPnl.add(dueDate);
     mainPnl.add(dueDateField);
     mainPnl.add(employeeId);
     mainPnl.add(employeeIdField);
     mainPnl.add(rentalPriceLbl);
     mainPnl.add(rentalPriceField);
     btnPnl.add(OkBtn);
     btnPnl.add(exitBtn);
     
     container.add(mainPnl,BorderLayout.CENTER);
     container.add(btnPnl,BorderLayout.SOUTH);
     
       setTitle("RENTAL DETAILS");
  setSize(300,200);
  setVisible(true);
  setResizable(false);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
           
 }
    
    public class rentHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource()==OkBtn){
          RecordRentalDetails();
            }
            if(ae.getSource()==exitBtn){
                dispose();
            }
        }
    }
    String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
      public void RecordRentalDetails(){
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="INSERT INTO RENTAL_DETAILS(MOVIE_COD,MOVIE_TITLE,DUE_DATE_RETURN,EMPLOYEE_ID,RENTAL_PRICE) VALUES"
                + "('"+movieCodField.getText()+"','"+movieTitleField.getText()+"','"+dueDateField.getText()+"','"+employeeIdField.getText()+"'"
                + ",'"+rentalPriceField.getText()+"')";
        stmt.execute(Query);
           JOptionPane.showMessageDialog(null, "Rental Details Stored Successfully.");
              }
              catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.toString());
              }      
        
        }
 
}
