/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem.Gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import videorentalsystem.CashPayment;
import videorentalsystem.Customer;
import videorentalsystem.RentalDetails;
import videorentalsystem.Receipt;
import java.util.Date;
import java.text.DateFormat;
/**
 *
 * @author JAYMACSBERG
 */
public class MainGuiInterface extends JFrame {
    Date date;
    DateFormat format;
    protected JLabel dateLbl;
 protected JMenuBar menuBar;
 protected JMenu Customer, Payment,Receipt,Rental,Details;
 protected JMenuItem NewCustomer,CheckDeliquency,checkOverDueDate,
         cashPayment,e_transfer,printReceipt,videoRental,Rental_Details;
 protected Container container;
 private ImageIcon imageIcon1;
 private JLabel imageLabel1;
 protected JPanel btnPnl,mainPanel;
 protected JButton ViewAvailableVideos,ViewRentedVideos,ExitBtn,OKBtn;
 
 
 public MainGuiInterface(){
     try{
     URL url = MainGuiInterface.class.getClassLoader().getResource("videorentalsystem/videos.jpg");
     imageIcon1 = new ImageIcon(url);
     }
     catch(Exception exp){
     JOptionPane.showMessageDialog(null, exp.toString());
     }
     imageLabel1 = new JLabel(imageIcon1);
        
     date= new Date();
     format=DateFormat.getDateInstance(DateFormat.MEDIUM);
     dateLbl= new JLabel(""+format.format(date));
     
     menuBar= new JMenuBar();
     Customer= new JMenu("Customer");
     Payment= new JMenu("Payment");
     Receipt= new JMenu("Receipt");
     Rental= new JMenu("Rental");
     Details= new JMenu("Details");
     
     ViewAvailableVideos= new JButton("Available Videos");
     ViewRentedVideos= new JButton("Rented Videos");
     ExitBtn= new JButton("Exit");
     OKBtn= new JButton("OK");
     
     mainPanel= new JPanel(new FlowLayout());
     btnPnl= new JPanel(new GridLayout(1,1));
     
     container= getContentPane();
     
     NewCustomer= new JMenuItem(" Set New Customer");
     CheckDeliquency= new JMenuItem("Check Deliquency");
     checkOverDueDate= new JMenuItem("Check Overdue Date");
     cashPayment= new JMenuItem("Cash Payment");
     e_transfer= new JMenuItem("e-Transfer");
     printReceipt= new JMenuItem("PrintReceipt");
     videoRental= new JMenuItem("Store New Video");
     Rental_Details= new JMenuItem("Rental_Details");
     
     Customer.add(NewCustomer);
     Customer.add(CheckDeliquency);
     Customer.add(checkOverDueDate);
     Payment.add(cashPayment);
     Payment.add(e_transfer);
     Receipt.add(printReceipt);
     Rental.add(videoRental);
     Details.add(Rental_Details);
     
     NewCustomer.addActionListener(new Listener());
     cashPayment.addActionListener(new Listener());
     ViewRentedVideos.addActionListener(new Listener());
     ExitBtn.addActionListener(new Listener());
     videoRental.addActionListener(new Listener());
     videoRental.addActionListener(new Listener());
     Rental_Details.addActionListener(new Listener());
     ViewAvailableVideos.addActionListener(new Listener());
     checkOverDueDate.addActionListener(new Listener());
     printReceipt.addActionListener(new Listener());
    
     btnPnl.add(ExitBtn);
     btnPnl.add(dateLbl);
     btnPnl.add(ViewAvailableVideos);
     btnPnl.add(ViewRentedVideos);
     
     mainPanel.add(imageLabel1);
     
     container.add(mainPanel,BorderLayout.CENTER);
     container.add(btnPnl,BorderLayout.SOUTH);
     
        ExitBtn.setFont( new Font( "ENGRAVERS MT", Font.ITALIC, 10 ) );
   ViewAvailableVideos.setFont( new Font( "ENGRAVERS MT", Font.ITALIC, 10 ) );
   ViewRentedVideos.setFont( new Font( "ENGRAVERS MT", Font.ITALIC, 10 ) );
   dateLbl.setFont( new Font( "ENGRAVERS MT", Font.ITALIC, 15 ) );
     mainPanel.setBorder(BorderFactory.createTitledBorder("SunSet  Rental System"));
     btnPnl.setBorder(BorderFactory.createTitledBorder(""));
     
     menuBar.add(Customer);  
     menuBar.add(Payment);  
     menuBar.add(Receipt);  
     menuBar.add(Rental);  
     menuBar.add(Details);  
       this.setJMenuBar(menuBar);
   
      setTitle("SUNSET RENTAL SYSTEM");
      Dimension frameSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(0,0, frameSize.width, frameSize.height);
        setSize(frameSize);
  setLocationRelativeTo(null);
  setVisible(true);
  setResizable(false);
  setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
     
 }
 public class Listener implements ActionListener{
     @Override
     public void actionPerformed(ActionEvent e){
         if(e.getSource()==NewCustomer){
          new Customer();   
         }
         if(e.getSource()==ExitBtn){
          dispose();   
         }
         if(e.getSource()==cashPayment){
          new CashPayment();
         }
         if(e.getSource()==Rental_Details){
          new RentalDetails();
         }
         if(e.getSource()==videoRental){
          new VideoRental();
         }
         if(e.getSource()==ViewAvailableVideos){
         new ViewVideos();
         }
         if(e.getSource()==ViewRentedVideos){
         new ViewRentedVideos();
         }   
         if(e.getSource()==printReceipt){
         new Receipt();
         }   
         if(e.getSource()==checkOverDueDate){
          Customer cust=  new Customer();
          cust.dispose();
          cust.checkOverDueDate();
        
         }
         
     }
 }}
