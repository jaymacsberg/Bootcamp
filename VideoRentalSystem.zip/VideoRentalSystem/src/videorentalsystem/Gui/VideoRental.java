





package videorentalsystem.Gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.text.DateFormat;
/**
 *
 * @author JAYMACSBERG
 */
public class VideoRental extends JFrame {
    Date rentDate;
    DateFormat format;
    
 protected JLabel idLbl, titleLbl,idField, CostLbl,producerLbl,DateLbl,DateField;
 protected JTextField  titleField, producerField,costField;
 protected JPanel mainPnl,btnPnl;
 protected Container container;
 protected JButton submitBtn,resetBtn,exitBtn;
 protected int serialNo=1;
 protected int VideoId=1;
 
 public VideoRental(){
     initComp();
     genVideoId();
     archiveSerialNumber();
   setTitle("VIDEO RENTAL");
  setSize(300,200);
  setVisible(true);
  setResizable(false);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE); 
 }
     protected void initComp(){
     rentDate= new Date();
     format=DateFormat.getDateInstance(DateFormat.MEDIUM);
     idLbl= new JLabel("Video ID:");
     titleLbl= new JLabel("Video Title:");
     CostLbl= new JLabel("Cost:");
     producerLbl= new JLabel("Producer:");
     DateLbl= new JLabel("Date Rented:");
     
     idField= new JLabel();
     titleField= new JTextField();
     producerField=new JTextField();
     costField=new JTextField();
     DateField= new JLabel(""+format.format(rentDate));
     
     mainPnl= new JPanel(new GridLayout(5,2));
     btnPnl= new JPanel(new FlowLayout());
     container=getContentPane();
     
     submitBtn= new JButton("Submit");
     resetBtn= new JButton("Reset");
     exitBtn= new JButton("Exit");
     
     mainPnl.add(idLbl);
     mainPnl.add(idField);
     mainPnl.add(titleLbl);
     mainPnl.add(titleField);
     mainPnl.add(CostLbl);
     mainPnl.add(costField);
     mainPnl.add(producerLbl);
     mainPnl.add(producerField);
     mainPnl.add(DateLbl);
     mainPnl.add(DateField);
     
     btnPnl.add(submitBtn);
     btnPnl.add(resetBtn);
     btnPnl.add(exitBtn);
     
     submitBtn.addActionListener(new handler());
     resetBtn.addActionListener(new handler());
     exitBtn.addActionListener(new handler());
     
     
     container.add(mainPnl,BorderLayout.CENTER);
     container.add(btnPnl,BorderLayout.SOUTH);
     }
     
  public class handler implements ActionListener{
   public void actionPerformed(ActionEvent e){
     if(e.getSource()==submitBtn){
         VideoQuery();
     }  
     if(e.getSource()==exitBtn){
       dispose();  
     }  
     if(e.getSource()==resetBtn){
     costField.setText("");        
     titleField.setText("");    
     producerField.setText("");    
     }
 }
  }
                  String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
  
   protected void archiveSerialNumber(){
    String prevSerialNo=null;
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="SELECT COUNT(SN) FROM VIDEOS";
        ResultSet rst=stmt.executeQuery(Query);
    
        if(rst.next()){
            prevSerialNo=rst.getString(1);
  
    }
        serialNo=Integer.parseInt(prevSerialNo);
        serialNo +=1;
    }
        catch(Exception e){
                JOptionPane.showMessageDialog(null,e.toString());
                }
    }
   public void VideoQuery(){    
       try{
              Connection connnect= DriverManager.getConnection(url,userName,password);
              Statement state=connnect.createStatement();
              
String Query= "INSERT INTO VIDEOS(SN,ID,TITLE,COST,PRODUCER,DATERECEIVED) VALUES('"+serialNo+"','"+idField.getText()+"',"
 + " '"+titleField.getText()+"', '"+costField.getText()+"','" +producerField.getText()+"','"+DateField.getText()+"')";
             
state.execute(Query);   
            JOptionPane.showMessageDialog(null, "New Video Data Stored Successfully.");
            genVideoId();
              }
              catch(SQLException ex){
                JOptionPane.showMessageDialog(null,ex.toString());
              }      
 }
   protected void genVideoId(){
    String prevVideoId=null;
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="SELECT COUNT(SN) FROM VIDEOS";
        ResultSet rst=stmt.executeQuery(Query);   
        if(rst.next()){
            prevVideoId=rst.getString(1);
    }
        VideoId=Integer.parseInt(prevVideoId);
        VideoId +=123456;
        idField.setText(""+VideoId);
    }
        catch(Exception e){
                JOptionPane.showMessageDialog(null,e.toString());
                }
    }
   }

