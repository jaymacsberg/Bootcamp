



package videorentalsystem.Gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.Date;
import java.text.DateFormat;
/**
 *
 * @author JAYMACSBERG
 */
public class ReceiptGui extends JFrame {
  private  Date receiptDate;
  private  DateFormat format;
    protected JLabel receiptNumberLbl,receiptNumberField,receiptDateLbl,receiptDateField,receiptAmnLbl,receiptAmnField;
    protected JPanel mainPanel;
    protected JButton PrintBtn,ExitBtn;
    protected Container container;
    public ReceiptGui(){
     initComponent(); 
     receiptNumberGenerator();
     
     setTitle("Print Receipt");
     setSize(300,150);
     setResizable(false);
     setVisible(true);
     setLocationRelativeTo(null);
    }
        private void initComponent(){
            receiptDate= new Date();
            
            format=DateFormat.getDateInstance(DateFormat.MEDIUM);
            
        receiptNumberLbl= new JLabel("Receipt Number: ");
        receiptNumberField= new JLabel("");
        receiptDateLbl= new JLabel("Receipt Date: ");
        receiptDateField= new JLabel(""+format.format(receiptDate));
        receiptAmnLbl= new JLabel("Receipt Amount: ");
        receiptAmnField= new JLabel("");
        
        PrintBtn= new JButton("Print Receipt");
        ExitBtn= new JButton("Exit");
        
        mainPanel= new JPanel(new GridLayout(4,2));
        container=getContentPane();
        
        mainPanel.add(receiptNumberLbl);
        mainPanel.add(receiptNumberField);
        mainPanel.add(receiptDateLbl);
        mainPanel.add(receiptDateField);
        mainPanel.add(receiptAmnLbl);
        mainPanel.add(receiptAmnField);
        mainPanel.add(PrintBtn);
        mainPanel.add(ExitBtn);    
        add(mainPanel,BorderLayout.CENTER);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
            String prevReceiptId=null;
        int receiptNumber=0;
        public void receiptNumberGenerator(){
            String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
    try{
        Connection con= DriverManager.getConnection(url,userName,password);
        Statement stmt=con.createStatement();
        String Query="SELECT COUNT(MEMSHIPID)FROM CUSTOMER";
        ResultSet rst=stmt.executeQuery(Query);
        if(rst.next()){
            prevReceiptId=rst.getString(1);
    }
        receiptNumber=Integer.parseInt(prevReceiptId);
        receiptNumber =receiptNumber+13579;
        receiptNumberField.setText(""+receiptNumber);
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null,e.toString());     
    }
}
}