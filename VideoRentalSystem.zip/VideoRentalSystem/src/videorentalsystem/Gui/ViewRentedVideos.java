
package videorentalsystem.Gui;

    import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
import java.util.Date;
import java.text.DateFormat;
/**
/**
 *
 * @author JAYMACSBERG
 */
public class ViewRentedVideos extends JFrame implements ActionListener{

Date rentedDate;
DateFormat format;
    protected JScrollPane tablePane;
    protected static JTable table;
    protected JButton rentBtn,exitBtn,SelectBtn;
    protected JPanel container, btnPanel,costPanel;
    protected JLabel displayCost,RentedDateLbl;
    
    public ViewRentedVideos(){
        ComponentInit();
        updateRentedVideosTable();
        setSize(800, 300);
        setTitle("RENTED VIDEOS");
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);
      /*  rentBtn.addActionListener(new Handler());
        SelectBtn.addActionListener(new Handler());*/
        exitBtn.addActionListener(this);
    }
    
    private void ComponentInit(){
       
        displayCost=new JLabel("");
       // rentBtn = new JButton("Rent");
        exitBtn = new JButton("Exit");
        container = new JPanel();
        costPanel = new JPanel(new FlowLayout());
        btnPanel = new JPanel(new FlowLayout());
        String[] colNames = {"CUSTOMER_NAME","MEMBERSHIPID","VIDEO ID","VIDEO TITLE",
                                "VIDEO_COST", "PRODUCER", 
                                 "Rented Date"};
        
        Object[][] rowData = {
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null},
	    {null, null, null, null}
            };
        table = new JTable();
        table.setModel(new DefaultTableModel(rowData, colNames));
        
        table.setPreferredScrollableViewportSize(new Dimension(500, 70));
        table.setFillsViewportHeight(true);
        tablePane = new JScrollPane(table);
        
        container.add(tablePane);
        btnPanel.add(exitBtn);
        costPanel.add(displayCost);
        add(tablePane);
        add(btnPanel, BorderLayout.SOUTH);
        add(costPanel, BorderLayout.PAGE_START);
    }
    
   public static void main(String[] args) {
        new ViewRentedVideos();
    }
    
     String url="jdbc:derby://localhost:1527/RENTALSYSTEM";
                          String userName="RENTAL";
                          String password="RENTAL";
    private void updateRentedVideosTable(){
        try {
                Connection conn = DriverManager.getConnection(url, userName, password);
                Statement stmt = conn.createStatement();
                String query = "SELECT * FROM RENTEDVIDEOS";
                ResultSet rs = stmt.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));          
            }
        catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.toString());
            }
}
@Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==exitBtn){
            dispose();
        }
    }
}
