


package videorentalsystem.Gui;
import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
//import java.awt.event.*;
import java.util.*;
/**
 *
 * @author JAYMACSBERG
 */
public class CustomerGui extends JFrame{
    Date startDate;
    DateFormat dateFormat;
 protected JLabel NameLbl,AddressLbl,PhoneLbl,memShipIdLbl,memshipIdField,memStartDate,memStartDateField;
 protected JTextField NameField,phoneField;
 protected JTextArea AddressField;
  protected JButton submitBtn,exitBtn;
  protected Container container;
  protected JPanel mainPnl,btnPnl;
  protected JLabel overDueDateDisplayLbl,movieCodDisplayLbl,titleDisplayLbl;
  
  public CustomerGui(){
      initComponent();
      setTitle("REGISTER NEW CUSTOMER:");
      setSize(450,250);
      setLocationRelativeTo(null);
      setResizable(false);
      setVisible(true);
      }
      
      private void initComponent(){
        overDueDateDisplayLbl= new JLabel();
        movieCodDisplayLbl= new JLabel();
        titleDisplayLbl= new JLabel();
                
          startDate= new Date();
     dateFormat= DateFormat.getDateInstance(DateFormat.MEDIUM);
     memStartDateField= new JLabel(""+dateFormat.format(startDate));
      
      NameLbl= new JLabel(" Name:");
      AddressLbl= new JLabel("Address:");
      PhoneLbl= new JLabel("Phone No:");
      memShipIdLbl= new JLabel("MemberShip Id:");
      memStartDate= new JLabel("MemberShip Start Date:");
      
      NameField= new JTextField(15);
      phoneField= new JTextField(10);
      memshipIdField= new JLabel("");
      AddressField= new JTextArea();
      
      submitBtn= new JButton("Submit");
      exitBtn= new JButton("exit");
      mainPnl= new JPanel();
      btnPnl= new JPanel(new FlowLayout());
      
      container= getContentPane();
      mainPnl.setLayout(new GridLayout(5,2));
      
      mainPnl.add(memShipIdLbl);
      mainPnl.add(memshipIdField);
      mainPnl.add(NameLbl);
      mainPnl.add(NameField);
      mainPnl.add(AddressLbl);
      mainPnl.add(AddressField);
      mainPnl.add(PhoneLbl);
      mainPnl.add(phoneField);
      mainPnl.add(memStartDate);
      mainPnl.add(memStartDateField);
      btnPnl.add(submitBtn);
      btnPnl.add(exitBtn);
      container.add(mainPnl,BorderLayout.CENTER);
      container.add(btnPnl,BorderLayout.SOUTH);
       setDefaultCloseOperation(EXIT_ON_CLOSE);    
      }
}
