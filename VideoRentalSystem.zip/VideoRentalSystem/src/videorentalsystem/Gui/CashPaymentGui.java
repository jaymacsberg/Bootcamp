



package videorentalsystem.Gui;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.util.*;
/**
 *
 * @author JAYMACSBERG
 */
public class CashPaymentGui extends JFrame {
 Date paymentdate;
 DateFormat format;
 Random random;
 int id;
 
 protected JLabel paymentNoLbl,DateLbl,paymentAmnLbl,DateField,paymentField,AmountField;
 protected JPanel mainPanel, BtnPnl;
 protected Container container;
 protected JButton OkBtn,resetBtn,exitBtn;
 
 public CashPaymentGui(){
  InitComponents();   
  setTitle("CASH PAYMENT");
  setSize(300,200);
  setVisible(true);
  setResizable(false);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
 }
     private void InitComponents(){
     random= new Random();  
     paymentdate= new Date();
     format= DateFormat.getDateInstance(DateFormat.MEDIUM);
  paymentNoLbl= new JLabel("Payment Number:");   
  DateLbl= new JLabel("Payment Date:");   
  paymentAmnLbl= new JLabel("Payment Amount:");   
  DateField= new JLabel(""+format.format(paymentdate));
  
  id= random.nextInt(10000000);
  paymentField= new JLabel(""+id);   
  AmountField= new JLabel();
  
  mainPanel= new JPanel();
  BtnPnl= new JPanel(new FlowLayout());
  container= getContentPane();
  mainPanel.setLayout(new GridLayout(3,2));
  
  OkBtn= new JButton("OK");
  resetBtn= new JButton("Reset");
  exitBtn= new JButton("exit");
  
  mainPanel.add(paymentNoLbl);
  mainPanel.add(paymentField);
  mainPanel.add(DateLbl);
  mainPanel.add(DateField);
  mainPanel.add(paymentAmnLbl);
  mainPanel.add(AmountField);
  
  BtnPnl.add(OkBtn);
  BtnPnl.add(resetBtn);
  BtnPnl.add(exitBtn);
 
  container.add(mainPanel,BorderLayout.CENTER);
  container.add(BtnPnl,BorderLayout.SOUTH);
     }
 public class CashHandler implements ActionListener{
   public void actionPerformed(ActionEvent e){
     if(e.getSource()==OkBtn){
     JOptionPane.showMessageDialog(null,"Paid Successfully!!!","Successfull",JOptionPane.INFORMATION_MESSAGE); 
     paymentField.setText("");
     AmountField.setText("");
     }  
     if(e.getSource()==exitBtn){
       dispose();  
     }  
     if(e.getSource()==resetBtn){
     paymentField.setText("");      
     AmountField.setText("");    
     }
 }
 }
 
}
