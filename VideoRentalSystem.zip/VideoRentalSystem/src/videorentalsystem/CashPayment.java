


package videorentalsystem;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import videorentalsystem.Gui.CashPaymentGui;
/**
 *
 * @author JAYMACSBERG
 */
public class CashPayment extends CashPaymentGui{
   /*--------------------------------
    The Constructor
    --------------------------------*/
    public CashPayment(){
        retrieveTotalCost();
         OkBtn.addActionListener(new CashPaymentGui.CashHandler());
  resetBtn.addActionListener(new CashPaymentGui.CashHandler());
  exitBtn.addActionListener(new CashPaymentGui.CashHandler());
    }
    
      String url="jdbc:derby://localhost:1527/RENTALSYSTEM";//table url
                          String userName="RENTAL";//table userName
                          String password="RENTAL";//table passowrd
      /*--------------------------------------------------
       Precondition: total amount must have been computed
        and stored in the database and it must not be less
        than or equal to zero
       --------------------------------------------------*/
    protected void retrieveTotalCost(){  //method to retrieve total Cost from the database Table
    try {
      Connection conn = DriverManager.getConnection(url, userName, password);
      Statement stmt = conn.createStatement();
      String value= JOptionPane.showInputDialog("Input Customer Unique Id");
      String Query = "SELECT * FROM COST WHERE CUSTOMER_ID='"+value+"'";
            
     ResultSet rs=  stmt.executeQuery(Query); 
       while(rs.next()){
       AmountField.setText(rs.getString(2));
            }
    }
     catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.toString());
        }   
   } 
    /*--------------------------------------------
    post Condition: total amount used to compute
    customer's total cost.
    --------------------------------------------*/
}
