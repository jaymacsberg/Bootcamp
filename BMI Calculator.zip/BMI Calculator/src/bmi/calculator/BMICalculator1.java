/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bmi.calculator;
import java.util.Scanner;

/**
 *
 * Matric Number: 2061400001
 * Department: Physics
 * 
 */
public class BMICalculator1 {
    
    Scanner userInput = new Scanner (System.in);
    float weight, height, BMI;
    /*---------------------------------------
    setters method for computation of weight
    ----------------------------------------/
    */    
    private void weightSetter(){
        System.out.print("Please Enter Your Weight in Kilograms: ");
        weight = userInput.nextFloat();
        System.out.print("\n");
    }
    private void heightSetter(){
        System.out.print("Please Enter Your Height in Metres: ");
        height = userInput.nextFloat();
        System.out.print("\n");
    }
    
    private void BMICalculation(){
        BMI = (weight) / (height*height);
        System.out.println("Your BMI is: " + BMI);
    }
    
    private void BMIScale(){
        if (BMI < 18.5)
            System.out.println("Your BMI is Underweight");
        if (BMI>= 18.5 && BMI <= 24.9)
            System.out.println("Your BMI is Normal");
        if (BMI>= 25 && BMI <= 29.9)
            System.out.println("Your BMI is Overweight");
        if (BMI>= 30)
            System.out.println("Your BMI is Obess");
        }
    
    public BMICalculator1(){
        
        weightSetter();
        heightSetter();
        BMICalculation();
        BMIScale();
    }
    
    public static void main(String[] args) {
        new BMICalculator1();
    }
    
}
