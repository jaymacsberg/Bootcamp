/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bmi.calculator;
import java.util.Scanner;

/*--------------------------
   matric Number 2061400006
 --------------------------*/
public class BMICalculator {
    
    double userWeight, userHeight, BMI;
    Scanner input = new Scanner (System.in);
        
    private void setWeight(){
        System.out.println("Please Enter Your Weight in Pounds: ");
        userWeight = input.nextDouble();
    }
    private void setHeight(){
        System.out.println("Please Enter Your Height in Inches: ");
        userHeight = input.nextDouble();
    }
    
    private void BMICalculation(){
        BMI = (userWeight * 703) / (userHeight*userHeight);
        System.out.println("User Your BMI is: " + BMI);
    }
    
    private void ScaleBMI(){
        if (BMI < 18.5)
            System.out.println("User Your BMI is 'Underweight'");
        if (BMI>= 18.5 && BMI <= 24.9)
            System.out.println("User Your BMI is 'Normal'");
        if (BMI>= 25 && BMI <= 29.9)
            System.out.println("User Your BMI is 'Overweight'");
        if (BMI>= 30)
            System.out.println("User Your BMI is 'Obess'");
        }
    
    public BMICalculator(){
        
        setWeight();
        setHeight();
        BMICalculation();
        ScaleBMI();
    }
    
    /*----------------------------
      main method
    ------------------------------------*/
    
    public static void main(String[] args) {
        new BMICalculator();
    }
}
