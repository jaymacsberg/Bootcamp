
package gpacalculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import viewCgpa.*;

/*
 @author JAYMACSBERG
 */
public class Gpa extends GpaGui{
  
    
    private JLabel total;
   private byte noOfCourses, courseUnit;
   int totalUnit;
 public Gpa(){
     total= new JLabel();
     noOfCourses=0;
    courseUnit=0;
     totalUnit=0; 
  
     calBtn.addActionListener(new handler());
     exitBtn.addActionListener(new handler());
     resetBtn.addActionListener(new handler());    
     cgpaBtn.addActionListener(new handler());    
     view.addActionListener(new handler());    
     update.addActionListener(new handler());    
 }
    
    protected byte getnoOfCourses(){        
      try{   
         noOfCourses=Byte.parseByte(noOfCOfferedField.getText());
    }
    catch(Exception e){
       JOptionPane.showMessageDialog(null,"noOfCourses Offered Field Must Not be Empty\n "
               + "or noOfCourses Offered Field Must be Digits!!!","Warning!!!",JOptionPane.WARNING_MESSAGE);
    }
         return noOfCourses ; 
        }
    
    protected  int getUnit(){
             
    totalUnit= Integer.parseInt(noOfCUnitField.getText());

     return totalUnit ;  
    }  
    
    
    protected void setGpa(){
      int gradePoint;
   int [] courses= new int[getnoOfCourses()];
   
 if(noOfCUnitField.getText().isEmpty()){
       JOptionPane.showMessageDialog(null,"TotalCourseUnit Field Must Not be Empty\n"
               + " or TotalCourseUnit Field Must be Digit!!!","Warning!!!",JOptionPane.WARNING_MESSAGE); 
       return;
    }
    try{
    for(int i=0; i<courses.length; i++){   
        String coursegrade =JOptionPane.showInputDialog("Input Course Grade in Capital Letter For "+(i+1)+" Course");
     String unit=JOptionPane.showInputDialog("Input Course Unit For "+(i+1)+" Course");
      courseUnit=Byte.parseByte(unit);
           
     switch(coursegrade){
        
          case "A":
          case "a":
            gradePoint= 5*courseUnit;
               courses[i]=gradePoint;
                break;
                  case "B":
                  case "b":
                    gradePoint= 4* courseUnit;
                      courses[i]=gradePoint;
                        break;
         case "C":
         case "c":
             gradePoint= 3* courseUnit;
               courses[i]=gradePoint;
                break;
                  case "D":
                  case "d":
                   gradePoint= 2* courseUnit;
                     courses[i]=gradePoint;
                      break;
         case "E":
         case "e":
             gradePoint= 1 * courseUnit;
               courses[i]=gradePoint;
                 break;
                   case "F":
                   case "f":
                     gradePoint= 0 * courseUnit;
                       courses[i]=gradePoint;
                         break;      
     }  
    }
  }
  catch(Exception e){
      JOptionPane.showMessageDialog(null,"A Course Grade or Course Unit Input Has Been Skipped!!!","Warnings!!!",
                       JOptionPane.WARNING_MESSAGE);
  }
    try{
 int Sum=0; String format;
    for (int count=0; count<courses.length; count++){
      Sum= Sum + courses[count];
         double GPA=  (double)Sum/getUnit();
           format=String.format("%.2f",GPA);
             gpaField.setText(""+format);
    }
    }
    catch(ArithmeticException ae){
      JOptionPane.showMessageDialog(null,ae.toString());      
            }
     }

protected void setCGPA(){
    try {
    double previousCGPA, gpa, sumTotalUnitCourse, sumCgpa, semesterCGPA, sumtotalCourseUnit;
    
       gpa=Double.parseDouble(gpaField.getText());
    
      previousCGPA=Double.parseDouble(pCgpaField.getText());
         sumTotalUnitCourse=Double.parseDouble(totUnitField.getText());
          sumCgpa=previousCGPA*sumTotalUnitCourse;
            semesterCGPA=(gpa*getUnit());
             sumtotalCourseUnit=sumCgpa +semesterCGPA;
             String form=String.format("%.0f",sumtotalCourseUnit);
            
     
    double sumUnitCourse= (sumTotalUnitCourse + getUnit());
  
       double CGPA=(double) sumtotalCourseUnit/sumUnitCourse;
        String format=String.format("%.2f",CGPA);
         CGPAField.setText(""+format);
         total.setText(""+sumUnitCourse);
 }
    catch(Exception e){
        JOptionPane.showMessageDialog(null,"Previous CGPA Field or sumTotalUnitCourse\nField must not be Empty!!!","Warnings!!!",JOptionPane.WARNING_MESSAGE);
    }
    /* try{
         String url="jdbc:derby://localhost:1527/STUDENT_GPA_DB";
         String userName="cgpadb";
         String password="0000";
         
         Connection con=DriverManager.getConnection(url,userName,password);
         Statement stmt=con.createStatement();
         
 String Query="INSERT INTO GRADE(STUDENTNAME, MATRIC_NUMBER, DEPARTMENT, LEVEL, SEMESTER, NOC_OFFERED, SEMTOTCREDITUNITS,"
       + "SEMGPA, SUMTOTUNITCOURSES, SEMCGPA) VALUES('"+nameField.getText()+"', '"+matNoField.getText()+"','"+deptBox.getSelectedItem()+"', "
        + "'"+levelBox.getSelectedItem()+"', '"+semBox.getSelectedItem()+"', '"+noOfCOfferedField.getText()+"', '"+noOfCUnitField.getText()+"',"
         + "'"+gpaField.getText()+"', '"+total.getText()+"', '"+CGPAField.getText()+"')";
           stmt.execute(Query);
          }
    catch(Exception e){
      JOptionPane.showMessageDialog(null,e.toString());  
    } */
}

   protected class handler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==calBtn){
            setGpa(); 
        } 
        if (ae.getSource()==resetBtn){
           nameField.setText("");  
            matNoField.setText("");  
             deptBox.setSelectedItem("Select");  
              levelBox.setSelectedItem("Select");  
               semBox.setSelectedItem("Select");  
                noOfCOfferedField.setText("");  
                  noOfCUnitField.setText("");  
                    gpaField.setText("");  
                     CGPAField.setText("");  
                      pCgpaField.setText("");  
                       totUnitField.setText("");  
            
        }
        if(ae.getSource()==cgpaBtn){
            try{
         setCGPA();   
           }
            catch(Exception e){
             JOptionPane.showMessageDialog(null,e.toString());   
            }
        }
        if(ae.getSource()==exitBtn){
           dispose();
        }
       if(ae.getSource()==view){
         View view= new View();
         view.retrievegrade();
        }
       if(ae.getSource()==update){
           Update update= new Update();
           update.setUpdateCgpa();
       }
      }
    }
}
