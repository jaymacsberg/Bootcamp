/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gpacalculator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author JAYMACSBERG
 */
public class GpaGui extends JFrame{
 
    protected JLabel nameLbl, matNoLbl, deptLbl, LvlLbl, semesterLbl;
    protected JLabel noOfCOfferedLbl, noOfCUnitLbl, gpaLbl, gpaField,
            pCgpaLbl,totalUnitLbl,CGPALbl,CGPAField;
    
    protected JTextField nameField, matNoField, noOfCOfferedField,
            noOfCUnitField,pCgpaField,totUnitField;
    
    protected JComboBox deptBox, levelBox, semBox;
    
    protected JButton calBtn, resetBtn, exitBtn,cgpaBtn,view,update;
    
    protected Container container;
    protected JPanel detPanel, gpaPanel, btnPanel,cgpaPanel;
    
    public GpaGui(){
     nameLbl= new JLabel("Student Name:");
     matNoLbl= new JLabel("MATRIC NUMBER:");
     deptLbl= new JLabel("DEPARTMENT:");
     LvlLbl= new JLabel("LEVEL:");
     semesterLbl=new JLabel("SEMESTER:");
     noOfCOfferedLbl= new JLabel("No Of Courses Offered:");
     noOfCUnitLbl= new JLabel("Total CreditUnits:");
     gpaLbl= new JLabel("SEMESTER GPA:");
     gpaField= new JLabel("");
     pCgpaLbl= new JLabel("Previous CGPA:");
     totalUnitLbl= new JLabel("SumTotalOfUnitCourses:");
     CGPALbl= new JLabel("Current CGPA:");
     CGPAField= new JLabel("");
     
     
     nameField= new JTextField();
     matNoField= new JTextField();
     noOfCOfferedField= new JTextField();
     noOfCUnitField= new JTextField();
     pCgpaField= new JTextField();
     totUnitField= new JTextField();
     
     calBtn= new JButton("GPA");
     resetBtn= new JButton("RESET");
     exitBtn= new JButton("EXIT");
     cgpaBtn= new JButton("CGPA");
     view= new JButton("VIEW STUDENT GPA/CGPA");
     update= new JButton("UPDATE STUDENT CGPA");
     
     deptBox= new JComboBox();
     levelBox= new JComboBox();
     semBox= new JComboBox();
     
     container=getContentPane();
     detPanel= new JPanel();
     btnPanel= new JPanel();  
     gpaPanel= new JPanel();
     cgpaPanel= new JPanel();
     
     detPanel.setLayout(new GridLayout(5,2));
     container.setLayout( new BorderLayout());
     btnPanel.setLayout(new FlowLayout());
     gpaPanel.setLayout(new GridLayout(3,2));
     cgpaPanel.setLayout(new GridLayout(6,2));
     
    deptBox.addItem("Select");
     deptBox.addItem("Botany");
           deptBox.addItem("Chemistry"); 
    deptBox.addItem("Computer Science");
       deptBox.addItem("Economics");  
     deptBox.addItem("Mathematics");
       deptBox.addItem("English");  
       deptBox.addItem("History");  
            deptBox.addItem("Microbiology");  
        deptBox.addItem("Physics");
        deptBox.addItem("Sociology");
       deptBox.addItem("TMA");  
       deptBox.addItem("VCA");  
      deptBox.addItem("Zoology");
     
     levelBox.addItem("Select");
     levelBox.addItem("100L");
     levelBox.addItem("200L");
     levelBox.addItem("300L");
     levelBox.addItem("400L");
     
     semBox.addItem("Select");
     semBox.addItem("1st");
     semBox.addItem("2nd");
     
     detPanel.add(nameLbl); detPanel.add(nameField);
detPanel.add(matNoLbl);  detPanel.add(matNoField);
detPanel.add(deptLbl);   detPanel.add(deptBox);
detPanel.add(LvlLbl);    detPanel.add(levelBox);
detPanel.add(semesterLbl); detPanel.add(semBox);
detPanel.setBorder(BorderFactory.createTitledBorder("STUDENT DETAILS"));
gpaPanel.add(noOfCOfferedLbl); gpaPanel.add(noOfCOfferedField);
gpaPanel.add(noOfCUnitLbl);    gpaPanel.add(noOfCUnitField);
gpaPanel.add(gpaLbl);          gpaPanel.add(gpaField);
cgpaPanel.add(pCgpaLbl);       cgpaPanel.add(pCgpaField);
cgpaPanel.add(totalUnitLbl);    cgpaPanel.add(totUnitField);
cgpaPanel.add(CGPALbl);          cgpaPanel.add(CGPAField);

gpaPanel.setBorder(BorderFactory.createTitledBorder("GPA CALCULATION:"));
cgpaPanel.setBorder(BorderFactory.createTitledBorder("CGPA CALCULATION:"));
cgpaPanel.add(calBtn);
cgpaPanel.add(cgpaBtn);
cgpaPanel.add(view);
cgpaPanel.add(update);
cgpaPanel.add(resetBtn);
cgpaPanel.add(exitBtn);

     container.add(detPanel,BorderLayout.NORTH);
     container.add(gpaPanel,BorderLayout.CENTER);
     container.add(cgpaPanel,BorderLayout.SOUTH);
setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

setTitle("GPA/CGPA CALCULATOR");
setSize(400, 530);
setLocationRelativeTo(null);
setResizable(false);
setVisible(true);

    }
}
