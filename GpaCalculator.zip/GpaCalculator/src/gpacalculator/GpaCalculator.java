/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gpacalculator;

import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author JAYMACSBERG
 */
public class GpaCalculator {
      
    public static void main(String[] args) {
    
        try {
   UIManager.put("nimbusBase", new Color(148,129,38));
UIManager.put("nimbusBlueGrey", new Color(148,129,38));
UIManager.put("control", new Color(211,188,75));

    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
   JOptionPane.showMessageDialog(null,e.toString());
}
  Gpa g= new Gpa();

    }
    
}
