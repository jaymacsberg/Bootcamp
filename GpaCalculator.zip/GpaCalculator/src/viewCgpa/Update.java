/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package viewCgpa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author JAYMACSBERG
 */
public class Update extends JFrame {
 
   private JLabel nameLbl,matLbl,depLbl,levelLbl, semLbl,semGpaLbl, 
           semUnitCourseLbl, courseOfferedLbl, previousCgpaLbl, currentCgpaLbl; 
   private JLabel nameField, matField, depField, previousCgpaField, currentCgpaField,total; 
   
   private JComboBox levelBox, semBox;
   
   private JTextField semGpaField,courseOfferedField, semUnitCourseField;
   private JPanel mainPanel;
   private Container con;
   private JButton updateBtn, exitBtn;
   
 public Update(){
  nameLbl= new JLabel("STUDENTNAME");
  nameField= new JLabel();
  matLbl= new JLabel("MATRIC-NUMBER:");
  matField= new JLabel();
  depLbl= new JLabel("DEPARTMENT:");
  depField= new JLabel();
   levelLbl= new JLabel("LEVEL:");
   semLbl= new JLabel("SEMESTER:");
   total= new JLabel();
   semGpaLbl= new JLabel("SEMESTER GPA:");
   semGpaField= new JTextField();
   semUnitCourseLbl= new JLabel("SEMES UNITCOURSE:");
   semUnitCourseField= new JTextField();
   previousCgpaLbl= new JLabel("PREVIOUS CGPA:");
   previousCgpaField= new JLabel();
   currentCgpaLbl= new JLabel("CURRENT CGPA");
   currentCgpaField= new JLabel();
   updateBtn= new JButton("update");
   exitBtn= new JButton("Exit");
   courseOfferedLbl= new JLabel("noOfCourseOffered:");
   courseOfferedField= new JTextField();
   levelBox= new JComboBox();
   semBox= new JComboBox();
   levelBox.addItem("Select");levelBox.addItem("100L"); levelBox.addItem("200L");
   levelBox.addItem("300L"); levelBox.addItem("400L");
   semBox.addItem("Select"); semBox.addItem("1st"); semBox.addItem("2nd");
   
   mainPanel= new JPanel(new GridLayout(11,2));
   con=getContentPane();
   con.setLayout(new BorderLayout());
   exitBtn.addActionListener(new handler());
   updateBtn.addActionListener(new handler());
   
   mainPanel.add(nameLbl);
   mainPanel.add(nameField);
   mainPanel.add(matLbl);
   mainPanel.add(matField);
   mainPanel.add(depLbl);
   mainPanel.add(depField);
   mainPanel.add(levelLbl);
   mainPanel.add(levelBox);
   mainPanel.add(semLbl);
   mainPanel.add(semBox);
   mainPanel.add(semGpaLbl);
   mainPanel.add(semGpaField);
   mainPanel.add(courseOfferedLbl);
   mainPanel.add(courseOfferedField);
   mainPanel.add(semUnitCourseLbl);
   mainPanel.add(semUnitCourseField);
   
   mainPanel.add(previousCgpaLbl);
   mainPanel.add(previousCgpaField);
   mainPanel.add(currentCgpaLbl);
   mainPanel.add(currentCgpaField);
   mainPanel.add(updateBtn);
   mainPanel.add(exitBtn);
   
   con.add(mainPanel,BorderLayout.CENTER);
   
   setTitle("GPA/CGPA UPDATE:");
   setSize(300,300);
   setResizable(false);
   setLocationRelativeTo(null);
   setVisible(true);  
   setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
 }   
    public static void main(String[]args){
        new Update();
    }
    public class handler implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e){
   if(e.getSource()==exitBtn){
       dispose();
   }       
    if(e.getSource()==updateBtn){
     getUpdateCgpa();   
    }       
    }
}
    String matNo;
    public void setUpdateCgpa(){
     try{ 
    String url="jdbc:derby://localhost:1527/STUDENT_GPA_DB";
    String userName="cgpadb";
    String password="0000";
    matNo=JOptionPane.showInputDialog("Input Student matric Number:");
     Connection connect=DriverManager.getConnection(url,userName,password);
     Statement stnt=connect.createStatement();
     String query="SELECT * FROM GRADE WHERE MATRIC_NUMBER='"+matNo+"'";
     ResultSet rs=stnt.executeQuery(query);
     while(rs.next()){
      nameField.setText(rs.getString(1)); 
      matField.setText(rs.getString(2));
      depField.setText(rs.getString(3));
      levelBox.setSelectedItem(rs.getString(4));
      semBox.setSelectedItem(rs.getString(5));
      total.setText(rs.getString(9));
      previousCgpaField.setText(rs.getString(10));      
     }  
     }
     catch(Exception ex){
      JOptionPane.showMessageDialog(null,ex.toString());   
     }        
    }
    
    protected void getUpdateCgpa(){
       try{
           
      double gpa=Double.parseDouble(semGpaField.getText());
      double unit=Double.parseDouble(semUnitCourseField.getText());
      double sumUnit=gpa*unit;
      double previous= Double.parseDouble(previousCgpaField.getText());
      double totalunit=Double.parseDouble(total.getText());
      double sumTotUnit= previous*totalunit;
      double gpaCgpaTotunit=sumUnit + sumTotUnit;
      double totUnitCourse= unit+totalunit;
      double cgpa= gpaCgpaTotunit/totUnitCourse;
      String format= String.format("%.2f",cgpa);
      currentCgpaField.setText(format);
      
           String url="jdbc:derby://localhost:1527/STUDENT_GPA_DB";
           String userName="cgpadb";
           String password="0000";
           Connection conn=DriverManager.getConnection(url,userName,password);
           Statement stmt=conn.createStatement();
           String Query="UPDATE GRADE SET SEMCGPA ='"+currentCgpaField.getText()+"',"
                   + "SUMTOTUNITCOURSES='"+totUnitCourse+"',SEMGPA='"+semGpaField.getText()+"',"
                   + "NOC_OFFERED='"+courseOfferedField.getText()+"',LEVEL='"+levelBox.getSelectedItem()+"'"
                   + ",SEMESTER='"+semBox.getSelectedItem()+"'WHERE MATRIC_NUMBER='"+matNo+"'";
           stmt.execute(Query);
           
       }
       catch(Exception e){
           JOptionPane.showMessageDialog(null,"Input Fields Must Not Be Empty","Warnings!!!",JOptionPane.WARNING_MESSAGE);
       }
        
        
        
    }
}
