/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package viewCgpa;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author JAYMACSBERG
 */
public class View extends JFrame {
 
    private JLabel nameLbl,nameField,matNoLbl, matNoField,deptLbl,deptField,
                   LvlLbl,levelField,semesterLbl,semField,gpaLbl,gpaField,CGPALbl,CGPAField;
    private JButton calBtn,exitBtn;
    private Container con;
    private JPanel mainp,btnp;
    
    public View(){
     nameLbl= new JLabel("STUDENTNAME:");   
     nameField= new JLabel();
     matNoLbl= new JLabel("MATRIC_NUMBER:");
     matNoField= new JLabel();
     deptLbl= new JLabel("DEPARTMENT:");
     deptField= new JLabel();
     LvlLbl= new JLabel("LEVEL:");
     levelField= new JLabel();
     semesterLbl= new JLabel("SEMESTER:");
     semField= new JLabel();
     gpaLbl= new JLabel("GPA:");
     gpaField= new JLabel();
     CGPALbl= new JLabel("CGPA:");
     CGPAField= new JLabel();
     
     //calBtn= new JButton("View");
     exitBtn= new JButton("Exit");
     
//     calBtn.addActionListener(new handler());
     exitBtn.addActionListener(new handler());
     
     con=getContentPane();   
     mainp= new JPanel(new GridLayout(7,2));
     btnp= new JPanel(new FlowLayout());
      
     mainp.add(nameLbl);   mainp.add(nameField);
     mainp.add(matNoLbl);  mainp.add(matNoField);
     mainp.add(deptLbl);    mainp.add(deptField);
     mainp.add(LvlLbl);      mainp.add(levelField);
     mainp.add(semesterLbl);  mainp.add(semField);
     mainp.add(gpaLbl);        mainp.add(gpaField);
     mainp.add(CGPALbl);        mainp.add(CGPAField);
    /* btnp.add(calBtn); */          btnp.add(exitBtn);
     mainp.setBorder(BorderFactory.createTitledBorder("VIEW STUDENT CGPA:"));
     con.add(mainp,BorderLayout.CENTER);
     con.add(btnp,BorderLayout.SOUTH);
     
     
     setTitle("VIEW STUDENT GPA/CGPA");
     setSize(400,200);
     setVisible(true);
     setResizable(false);
     setLocationRelativeTo(null);
     setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    }
  public class handler implements ActionListener{
   @Override
      public void actionPerformed(ActionEvent e){
      /* if(e.getSource()==calBtn){
          retrievegrade(); 
       }  */ 
       if(e.getSource()==exitBtn){
           dispose();
       }
      }
  }
  public void retrievegrade(){
     try{
         String url="jdbc:derby://localhost:1527/STUDENT_GPA_DB";
         String userName="cgpadb";
         String password="0000";
         Connection connect=DriverManager.getConnection(url,userName,password);
         Statement state=connect.createStatement();
         String mat=JOptionPane.showInputDialog("Input Student matric Number:");
         //String level=JOptionPane.showInputDialog("Input Student Level:");
        // String sem=JOptionPane.showInputDialog("Input Student Semester:");
         String Query="SELECT STUDENTNAME,MATRIC_NUMBER,DEPARTMENT,LEVEL,SEMESTER,SEMGPA,SEMCGPA FROM GRADE"
                 + " WHERE MATRIC_NUMBER ='"+mat+"'";
         
         ResultSet rs=state.executeQuery(Query);
         while(rs.next()){
          nameField.setText(rs.getString(1));
          matNoField.setText(rs.getString(2));
          deptField.setText(rs.getString(3));
          levelField.setText(rs.getString(4));
          semField.setText(rs.getString(5));
          gpaField.setText(rs.getString(6));
          CGPAField.setText(rs.getString(7));
        
         }
     } 
     catch(Exception ex){
       JOptionPane.showMessageDialog(null,ex.toString());  
     }     
  }
 /* public static void main(String[]args){
            try {
  UIManager.put("nimbusBase", new Color(148,129,38));
UIManager.put("nimbusBlueGrey", new Color(148,129,38));
UIManager.put("control", new Color(211,188,75));

    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
   JOptionPane.showMessageDialog(null,e.toString());
}
      new View();
  } */ 
  
}
