
package simplecalculator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static java.lang.Math.sqrt;
//import static java.lang.Math.pow;
/**
 * @author JAYMACSBERG
 */
public class CalculatorGUI extends JFrame {
    double total1, total2, sum;
    char operator;
    
 private final JTextArea textField;
 private final JButton numBtn [];
 private final JPanel fieldPnl, numPnl, operatorPnl;
 
 private final  JButton plus, minus, divide,
         multiply, equal, zero,modulus, sq,clear, dot,pow,per;
 private final Container container;
 
 private final JMenuBar menuBar;
 private final JMenu view, edit, help,exit;
 private final JMenuItem scientific,standard, copy,paste;
    
 public CalculatorGUI(){
     total1=0.0;
     total2=0.0;
     sum=0.0;
  
     menuBar= new JMenuBar();
     view= new JMenu("View");
     edit= new JMenu("edit");
     help= new JMenu("help");
     exit= new JMenu("exit");
    standard= new JMenuItem("Standard  Alt+1");
    scientific= new JMenuItem("Scientific  Alt+2");
    copy= new JMenuItem("Copy  Ctrl+C");
    paste= new JMenuItem("Paste  Ctrl+V");
  
     view.add(standard);
     view.add(scientific); 
     edit.add(copy); edit.add(paste);
     menuBar.add(view); menuBar.add(edit); menuBar.add(help); menuBar.add(exit);
     
  textField= new JTextArea();
     textField.setColumns(15);
        textField.setRows(2);
        
  numBtn= new JButton [10];
  for (int i=9; i>=1; i--){
      numBtn[i]= new JButton(""+i);
  }
  plus= new JButton("+");
  minus= new JButton("-");
  divide= new JButton("/");
  multiply= new JButton("*");
  equal= new JButton("=");
  zero= new JButton("0");
  modulus= new JButton("%");
  sq= new JButton("V");
  clear= new JButton("CE");
  dot= new JButton(".");
  pow= new JButton("^");
  per= new JButton("p");
  
  fieldPnl= new JPanel(new FlowLayout());
  numPnl= new JPanel(new GridLayout(3,3));
  operatorPnl= new JPanel(new GridLayout(4,3));
  container=getContentPane();
  this.setJMenuBar(menuBar);
  fieldPnl.add(textField);
  
  for(int j=9; j>=1; j--){
      numPnl.add(numBtn[j]);
  }
  operatorPnl.add(clear);
  operatorPnl.add(per);
  operatorPnl.add(pow);
  operatorPnl.add(plus);
  operatorPnl.add(minus);
  operatorPnl.add(divide);
  operatorPnl.add(multiply);
  operatorPnl.add(modulus);
  operatorPnl.add(sq);
  operatorPnl.add(zero);
  operatorPnl.add(dot);
  operatorPnl.add(equal);
  
  container.add(fieldPnl,BorderLayout.NORTH);
  container.add(numPnl,BorderLayout.WEST);
  container.add(operatorPnl,BorderLayout.EAST);
  for(int l=1; l<numBtn.length; l++){
      
  numBtn[l].addActionListener(new Handler());
  }
    Handler H= new Handler();  
  plus.addActionListener(H);
  minus.addActionListener(H);
  divide.addActionListener(H);
  multiply.addActionListener(H);
  modulus.addActionListener(H);
  clear.addActionListener(H);
  zero.addActionListener(H);
  equal.addActionListener(H);
  dot.addActionListener(H);
  sq.addActionListener(H);
  pow.addActionListener(H);
    exit.addActionListener(H);
    per.addActionListener(H);
  
  setTitle("Simple Calculator");
  setSize(280,200);
  setLocationRelativeTo(null);
  setVisible(true);
  setResizable(false);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
 }
    public class Handler implements ActionListener{
    
        @Override
        public void actionPerformed(ActionEvent ae){
    for (int k=1; k<numBtn.length; k++){
        if(ae.getActionCommand().equals(""+k)){
         textField.append(""+k);   
        }
    }   
    if(ae.getSource()==plus){
        String text= plus.getText();
        getOperator(text);
   
    }
    if(ae.getSource()==minus){
        String text= minus.getText();
        getOperator(text);
      
    }
    if(ae.getSource()==divide){
        String text= divide.getText();
        getOperator(text);
    }
    if(ae.getSource()==pow){
        String text= pow.getText();
        getOperator(text);
  
    }
    if(ae.getSource()==multiply){
      String text= multiply.getText(); 
      getOperator(text);
    }
    if(ae.getSource()==clear){
        textField.setText("");
    }
    if(ae.getSource()==modulus){
        String text= modulus.getText();
        getOperator(text);
  
    }
    if(ae.getSource()==zero){
        textField.append("0");
    }
    if(ae.getSource()==dot){
        textField.append(".");
    }
    if(ae.getSource()==sq){
     String text= sq.getText();
     getOperator(text);
    }
    if(ae.getSource()==equal){
      Validate();
      }
    if(ae.getSource()==per){
     String text= per.getText();
     getOperator(text);    
    }
    if(ae.getSource()==exit){
      dispose();
    }
        }
  }
    
    protected void getOperator(String btnText){
     operator= btnText.charAt(0);  
     total1 =Double.parseDouble(textField.getText());
     textField.setText("");
    }
   protected void Validate(){
    switch(operator){
        case '+':
        total2=Double.parseDouble(textField.getText());
        sum=total1 + total2;
                textField.setText(""+sum);
        total1=0;
            break;
        case '-':
            total2=Double.parseDouble(textField.getText());
            sum=total1 - total2;
            textField.setText(""+sum);
            total1=0;
            break;
            case'*':
                total2=Double.parseDouble(textField.getText());
                sum= total1 * total2;
                textField.setText(""+sum);
                break;
            case '/':
            total2=Double.parseDouble(textField.getText());
                sum=total1 / total2;
               textField.setText(""+sum);
                break;
            case '%':
                total2=Double.parseDouble(textField.getText());
                sum=total1 % total2;
                textField.setText(""+sum);
                break;
            case 'V':
             sum=sqrt(total1);  
                textField.setText(""+sum);
                break;
            case '^':
               int Total2=Integer.parseInt(textField.getText());
             sum=power(total1, Total2);  
                textField.setText(""+sum);
                break;  
            case 'p':
             double tot2=Integer.parseInt(textField.getText());
                sum=percentage(total1, tot2);
                textField.setText(""+sum);
                break;
           // case '!':
    }   
    
   }
   protected double power(double first, int second){
     
      try{
     int w[]= new int[second];
     double sum=1;
     for (int i=0; i<w.length; i++){
          sum= sum  * first;
     }
       
      }
       catch(Exception e){
           JOptionPane.showMessageDialog(this, e.toString());
   }
     return sum;
       }
   protected double percentage(double first, double second){
       double sec=second; 
       double f= first;
       double divide= f/100;
       double mult= sec * divide;
       return mult;
   }
   protected int factorial(double fact){
    int answer=1;
    for (int i=2; i<=fact; i++){
        answer= answer * i;
    }
       return answer;
   }
    }
