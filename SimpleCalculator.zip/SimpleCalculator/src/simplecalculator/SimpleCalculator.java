/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplecalculator;

import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author JAYMACSBERG
 */
public class SimpleCalculator {
    public static void main(String[] args) {     
        try {
   UIManager.put("nimbusBase", new Color(188,179,68));
UIManager.put("nimbusBlueGrey", new Color(108,120,98));
UIManager.put("control", new Color(150,150,89));

    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
   JOptionPane.showMessageDialog(null,e.toString());
}
      new CalculatorGUI();
    }
    
}
