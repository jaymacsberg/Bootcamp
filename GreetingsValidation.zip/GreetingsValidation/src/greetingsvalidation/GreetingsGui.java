/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package greetingsvalidation;

import java.awt.*;
 import javax.swing.*;
  import java.util.Date;
   import java.text.DateFormat;
    import java.util.Locale;
/**
 *
 * @author JAYMACSBERG
 * matric Number: 2031300015
 * department: Computer Science
 */
public class GreetingsGui extends JFrame{
    
    Date displayDate;
    DateFormat format;
    protected JTextField greetingsField;
    protected JPanel topLeftPanel,btnPanel,downLeftPanel,topRightPanel,downRightPanel;
    protected JLabel outputLabel,greetLbl,dateLbl,background;
    protected JButton valBtn, resetBtn,exitBtn;
    protected Container container;
    
    public GreetingsGui(){
        
        displayDate= new Date();
         format= DateFormat.getDateInstance(DateFormat.MEDIUM);
        
        outputLabel= new JLabel("");
         dateLbl= new JLabel(""+format.format(displayDate));
          greetingsField= new JTextField(20);
           greetLbl= new JLabel("INPUT GREETINGS");
            greetLbl.setForeground(new Color(150,250,150));
             dateLbl.setForeground(new Color(150,250,150));
              outputLabel.setForeground(new Color(150,250,150));
        
     
     topLeftPanel= new JPanel();
      downLeftPanel= new JPanel();
       topRightPanel= new JPanel();
        downRightPanel= new JPanel();
         btnPanel= new JPanel();
     
     valBtn= new JButton("Validate Greeting");
           valBtn.setForeground(new Color(42,171,86));
      resetBtn= new JButton("Reset");
           resetBtn.setForeground(new Color(42,171,86));
       container=getContentPane();
        ImageIcon icon= new ImageIcon("‪C:\\Users\\Accer\\Pictures\\downloaded images\\acer free logoacer wallpaper (11).jpg");
         background= new JLabel(icon);
     
     topLeftPanel.setLayout(null);
      downLeftPanel.setLayout(new FlowLayout());
       topRightPanel.setLayout(new FlowLayout());
        topRightPanel.add(dateLbl);
         downRightPanel.setLayout(new FlowLayout());
          btnPanel.setLayout(new FlowLayout());
           container.setLayout(new BorderLayout());
            background.setLayout(null);
     
     topLeftPanel.setBounds(0,0,180,50);
      downLeftPanel.setBounds(0,120,180,50);
       topRightPanel.setBounds(220,0,175,50);
        downRightPanel.setBounds(220,120,175,50);
     
     greetLbl.setFont( new Font( "DIGIFACEWIDE", Font.LAYOUT_LEFT_TO_RIGHT,20));
     dateLbl.setFont( new Font( "DIGIFACEWIDE", Font.LAYOUT_LEFT_TO_RIGHT,15));
      outputLabel.setFont( new Font( "ENGRAVERS MT", Font.ITALIC,13));
      valBtn.setFont( new Font( "ENGRAVERS MT", Font.ITALIC,10));
       resetBtn.setFont( new Font( "ENGRAVERS MT", Font.ITALIC,10));
        topLeftPanel.setBackground(new Color(113,141,115));
         downLeftPanel.setBackground(new Color(113,141,115));
          topRightPanel.setBackground(new Color(113,141,115));
           downRightPanel.setBackground(new Color(113,141,115));
            background.setBackground(new Color(105,149,109));
     
     downLeftPanel.add(valBtn);
      downRightPanel.add(resetBtn);
     
     background.add(topLeftPanel);
      background.add(downLeftPanel);
       background.add(topRightPanel);
        background.add(downRightPanel);
     
     greetingsField.setBounds(20,70,350, 30);
      background.add(greetingsField);
      
      outputLabel.setBounds(20,90,350, 30);
       background.add(outputLabel);
       
       greetLbl.setBounds(90,35,350,50);
        background.add(greetLbl);
     
     add(background,BorderLayout.CENTER);
      setDefaultCloseOperation(EXIT_ON_CLOSE);
    
    topLeftPanel.setBorder(BorderFactory.createTitledBorder(""));
     downLeftPanel.setBorder(BorderFactory.createTitledBorder(""));
      topRightPanel.setBorder(BorderFactory.createTitledBorder(""));
       downRightPanel.setBorder(BorderFactory.createTitledBorder(""));
        background.setBorder(BorderFactory.createTitledBorder(""));
     
     setTitle("GREETINGS VALIDATION");
      setSize(400,200);
       setVisible(true);
        setLocationRelativeTo(null);
         setResizable(false);
    } 
}
