
package greetingsvalidation;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author JAYMACSBERG
 * matric Number: 2031300015
 * department: Computer Science
 */
public class Greetings extends GreetingsGui {
    char firstInput;
    String userInput;
      
    public Greetings(){
     valBtn.addActionListener(new handler());
     resetBtn.addActionListener(new handler());
    }
    
    
    protected void correctFormatValidation(){
    userInput = greetingsField.getText().toLowerCase();
   String[]comparedWords={"good afternoon","good morning","good evening","hello sir","good morning ma",
                          "good day sir","good day ma","hello bro","good morning madam","good morning boss",
                            "good afternoon boss","good evening boss","morning sir","morning ma","afternoon ma","afternoon sir",
                              "evening sir","evening ma","hello there"};  
 
          if(userInput.endsWith(".") || userInput.endsWith("?")|| userInput.endsWith("!")){    
            }
            else{
JOptionPane.showMessageDialog(null,"Your Greeting is Not Properly Punctuated","Error!!!",JOptionPane.ERROR_MESSAGE);      
            return;    
            }
   for(int i=0; i<comparedWords.length; i++)
       if(userInput.contains(comparedWords[i]) && (Character.isUpperCase(firstInput))){
          outputLabel.setText("Correct Greeting Format!!!");
        JOptionPane.showMessageDialog(null,"  Nicely Punctuated\n Correct Greeting Format!!!","Greeting Validation",JOptionPane.INFORMATION_MESSAGE); 
        break;
     }
   } 
    protected void VanacularGreetings( String textInput){
        
    String [] selectedWords={"how you","good you","wetin dey","afternoon good","morning good",
                             "evening good","how far","whats up","guy how far","good sir morning",
                              "sir morning","good sir","sir afternoon","sir evening","there hello"}; 
       
 for(int i=0; i<selectedWords.length; i++)
  if( textInput.contains(selectedWords[i])){
   JOptionPane.showMessageDialog(null,"invalid Greeting Format ! ! !\n Check the Sentence and Try Again","Error!!!",JOptionPane.ERROR_MESSAGE);
      }
    }
       
    private class handler implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent ae){
        
     if(ae.getSource()==valBtn){
         if(greetingsField.getText().isEmpty()){
             JOptionPane.showMessageDialog(null,"The Input Field Must Not be Empty","Warning!!!",JOptionPane.WARNING_MESSAGE);
     }
         else{
             firstLetterValidation();
             correctFormatValidation();
             VanacularGreetings(userInput);
         }
     } 
     if(ae.getSource()==resetBtn){
         greetingsField.setText("");
         outputLabel.setText("");
     }
     }
  }  
    protected void firstLetterValidation(){
        firstInput=greetingsField.getText().charAt(0); 
        if(Character.isLowerCase(firstInput)){
JOptionPane.showMessageDialog(null,"The First Letter Must be Capital Letter","Invalid Greeting Format!!!",JOptionPane.ERROR_MESSAGE); 
        }
    }
   }
