
package greetingsvalidation;

import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author JAYMACSBERG
 * matric Number: 2031300015
 * department: Computer Science
 */
public class GreetingsValidation {

    public static void main(String[] args) {
try {
    UIManager.put("nimbusBase", new Color(255,225,255));
UIManager.put("nimbusBlueGrey", new Color(255,255,255));
UIManager.put("control", new Color(120,134,121));

    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
   JOptionPane.showMessageDialog(null,e.toString());
}
          new Greetings();
    }
    
}
